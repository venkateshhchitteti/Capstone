// import React, { Component, useState } from 'react'
 
// import EmojiRating from 'react-emoji-rating';
 
//  const Emoji=({Emoji,setEmoji})=>{
//     const [data,setData]=useState(''); 
//     return (
//       <div>
//         <EmojiRating 
//           variant='classic'
//           onChange={this.handleRating} />
//           <button onClick={()=>setEmoji(!Emoji)}>Submit</button>
//       </div>
//     )
// }
// export default Emoji;