
import React, { Component } from 'react';

function Home() {
    return (
        <div>
            <h1>Welcome To Spark Clothing Shoppping Enjoy the Offers Here....</h1>
        </div>
    )

}

export default Home;