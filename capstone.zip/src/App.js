import logo from './logo.svg';
import './App.css';
import Header from './component/Header';
import Main from './component/Main';
import Basket from './component/Basket';
import Products from './Products';
// import product from '/capstone/appname/db.json';
import { BrowserRouter as Router, Route, NavLink, Switch, Routes, BrowserRouter } from "react-router-dom";
import { HashLink as Link } from 'react-router-hash-link';
import Aboubtus from './component/Aboubtus';
import Home from './component/Home';
function App() {
  return (
    <Router>
      <div className="App">
        {/* <ul className="App-header">
              <li>
                <Link to="/">Home</Link>
              </li>
              <li>
                <Link to="/about">About Us</Link>
              </li>
              <li>
                <Link to="/contact">Contact Us</Link>
              </li>
            </ul> */}
            {/* <div className='inner'>{
              product && product.map(product =>{
                return(
                  <div className='box'>
                    <img src=''/>
                    <br />
                  </div>
                )
              })
            }

            </div> */}
        <div className='App1'>
          <Header></Header>
          <div>
            <Main></Main>
            <div>
            </div>
            <Basket></Basket>
          </div>
        </div>
        
        <Routes>
          <Route exact path='/Products' element={< Products />}></Route>
          <Route exact path='/Aboubtus' element={< Aboubtus />}></Route>
          <Route exact path='/Home' element={<Home/>}></Route>
        </Routes>
      </div>
    </Router>

  );
}

export default App;