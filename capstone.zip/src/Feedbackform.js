import axios from "axios";
import React, { useState } from "react";
import '/capstone/appname/src/Feedbackform.css';

function Feedbackform() {
  const [data, setData] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phoneno, setPhoneno] = useState('');
  const [feedback, setFeedback] = useState('');

  const handlename = (event) => {
    setName(event.target.value);
    console.log(event.target.value);
  }
  const handleemail = (event) => {
    setEmail(event.target.value);
  }
  const handlephoneno = (event) => {
    setPhoneno(event.target.value);
  }
  const handlefeedback = (event) => {
    setFeedback(event.target.value);
  }
  const handlesubmit = (event) => {
    console.log(name, email, phoneno, feedback, "venkateshh");
    event.preventDefault();
    let formdata={};
    formdata.name=name;
    formdata.email=email;
    formdata.phoneno=phoneno;
    formdata.feedback=feedback;
    axios.post('http://localhost:3000/feedbackform',formdata).then(function (response) {
        console.log(response);
    })
  }

  return (
    <div>
      <div >
        <form onSubmit={handlesubmit}>
          <h1 >
            FeedbackForm</h1>
          <div>
            <label>
              Name:
              <input placeholder="Enter your Name:" id="Name" type="text" onChange={handlename} /><br />
            </label>
          </div>
          <div>
            <label>
              Email:
              <input placeholder="Enter your Email:" id="Email" type="email" onChange={handleemail} /><br />
            </label>
          </div>
          <div>
            <label>
              PhoneNo:
              <input placeholder="Enter your PhoneNumber" id="Phoneno" type="number" onChange={handlephoneno} /><br />
            </label>
          </div>
          <div>
            <label>
              Feedback:
              <textarea placeholder="minimum 50 words" id="Feedback" type="text" onChange={handlefeedback} />
            </label>
          </div>
          {/* <ol id="feedbackform">
           
          </ol> */}
          <input type="submit" />
        </form>
        {/* <button onClick={() => setFeedback(!feedback)}>Submit</button> */}
      </div>

    </div>
  )
}
export default Feedbackform;